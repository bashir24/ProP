package ga.framework.operators;

@SuppressWarnings("serial")
public class EvolutionException extends Exception {
	public EvolutionException(String msg) {
		super(msg);
	}
}
