package ga.framework.model;

@SuppressWarnings("serial")
public class NoSolutionException extends Exception {
	public NoSolutionException(String msg) {
		super(msg);
	}
}
