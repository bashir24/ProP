public class Main {
	public static void main(final String[] args) {
		new Platformer();
	}
}